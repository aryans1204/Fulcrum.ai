from fastapi import FastAPI

chatbot_app = FastAPI()

#@app.post("/send_message"):

