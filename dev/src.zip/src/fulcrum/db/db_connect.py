import mongoengine

mongoengine.connect(db="test")


